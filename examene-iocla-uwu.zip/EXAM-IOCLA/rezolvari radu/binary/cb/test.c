#include <stdio.h>

int main(void)
{

  // TODO c)
  starship("into the darkness",-0x54524542);
	return 0;
}
